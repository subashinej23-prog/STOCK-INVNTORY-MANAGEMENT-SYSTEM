#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define PRODUCT_NAME_LENGTH 50
#define INPUT_LENGTH 256
#define DATA_FILE "inventory.dat"

typedef struct Product {
    int productID;
    char productName[PRODUCT_NAME_LENGTH];
    int currentStock;
    int minThreshold;
    float unitPrice;
    struct Product *next;
} Product;

static Product *inventoryHead = NULL;

/*
 * Reads a complete line, discarding overlong input so it cannot spill into
 * the next prompt. Returns 0 on end-of-file.
 */
static int read_line(const char *prompt, char *buffer, size_t bufferSize)
{
    for (;;) {
        size_t length;

        fputs(prompt, stdout);
        fflush(stdout);

        if (fgets(buffer, (int)bufferSize, stdin) == NULL) {
            return 0;
        }

        length = strlen(buffer);
        if (length > 0 && buffer[length - 1] == '\n') {
            buffer[--length] = '\0';
        } else if (!feof(stdin)) {
            int character;
            while ((character = getchar()) != '\n' && character != EOF) {
                /* Discard the remainder of this overlong line. */
            }
            puts("Input is too long. Please try again.");
            continue;
        }

        if (length > 0 && buffer[length - 1] == '\r') {
            buffer[length - 1] = '\0';
        }
        return 1;
    }
}

static void skip_whitespace(char **text)
{
    while (**text != '\0' && isspace((unsigned char)**text)) {
        ++(*text);
    }
}

static int read_integer(const char *prompt, int minimum, int maximum, int *value)
{
    char input[INPUT_LENGTH];
    char *end;
    long parsed;

    for (;;) {
        if (!read_line(prompt, input, sizeof(input))) {
            return 0;
        }

        errno = 0;
        parsed = strtol(input, &end, 10);
        skip_whitespace(&end);
        if (input[0] != '\0' && end != input && *end == '\0' && errno != ERANGE &&
            parsed >= minimum && parsed <= maximum) {
            *value = (int)parsed;
            return 1;
        }
        printf("Enter a whole number between %d and %d.\n", minimum, maximum);
    }
}

static int read_price(const char *prompt, float *value)
{
    char input[INPUT_LENGTH];
    char *end;
    float parsed;

    for (;;) {
        if (!read_line(prompt, input, sizeof(input))) {
            return 0;
        }

        errno = 0;
        parsed = strtof(input, &end);
        skip_whitespace(&end);
        if (input[0] != '\0' && end != input && *end == '\0' && errno != ERANGE &&
            isfinite(parsed) && parsed >= 0.0f) {
            *value = parsed;
            return 1;
        }
        puts("Enter a valid, non-negative price.");
    }
}

static int valid_product_name(const char *name)
{
    const unsigned char *character = (const unsigned char *)name;

    if (*name == '\0') {
        return 0;
    }
    while (*character != '\0') {
        if (*character == '|' || *character < 32) {
            return 0;
        }
        ++character;
    }
    return 1;
}

static Product *find_product(int productID)
{
    Product *current = inventoryHead;
    while (current != NULL) {
        if (current->productID == productID) {
            return current;
        }
        current = current->next;
    }
    return NULL;
}

static int append_product(Product *product)
{
    Product **link = &inventoryHead;

    while (*link != NULL) {
        if ((*link)->productID == product->productID) {
            return 0;
        }
        link = &(*link)->next;
    }
    product->next = NULL;
    *link = product;
    return 1;
}

static void print_stock_status(const Product *product)
{
    if (product->currentStock <= product->minThreshold) {
        if (product->currentStock == 0) {
            printf("[LOW STOCK ALERT] %s (ID %d) is OUT OF STOCK.\n",
                   product->productName, product->productID);
        } else {
            printf("[LOW STOCK ALERT] %s (ID %d): %d remaining; minimum is %d.\n",
                   product->productName, product->productID,
                   product->currentStock, product->minThreshold);
        }
    }
}

static int save_inventory(void)
{
    FILE *file = fopen(DATA_FILE, "w");
    const Product *current;

    if (file == NULL) {
        perror("Could not open inventory.dat for saving");
        return 0;
    }

    for (current = inventoryHead; current != NULL; current = current->next) {
        if (fprintf(file, "%d|%s|%d|%d|%.9g\n",
                    current->productID, current->productName,
                    current->currentStock, current->minThreshold,
                    (double)current->unitPrice) < 0) {
            perror("Could not write inventory.dat");
            fclose(file);
            return 0;
        }
    }

    if (fclose(file) != 0) {
        perror("Could not finish saving inventory.dat");
        return 0;
    }
    return 1;
}

static int load_inventory(void)
{
    FILE *file = fopen(DATA_FILE, "r");
    char line[INPUT_LENGTH];
    int lineNumber = 0;

    if (file == NULL) {
        if (errno != ENOENT) {
            perror("Could not open inventory.dat");
            return 0;
        }
        puts("No existing inventory.dat found. Starting with an empty inventory.");
        return 1;
    }

    while (fgets(line, sizeof(line), file) != NULL) {
        int productID;
        int stock;
        int threshold;
        int consumed = 0;
        int fields;
        float price;
        char name[PRODUCT_NAME_LENGTH];
        char *newline;
        Product *product;

        ++lineNumber;
        newline = strchr(line, '\n');
        if (newline != NULL) {
            *newline = '\0';
        } else if (!feof(file)) {
            int character;
            while ((character = fgetc(file)) != '\n' && character != EOF) {
                /* Discard malformed records longer than the line buffer. */
            }
            fprintf(stderr, "Skipping overlong record on line %d.\n", lineNumber);
            continue;
        }
        newline = strchr(line, '\r');
        if (newline != NULL) {
            *newline = '\0';
        }

        fields = sscanf(line, "%d|%49[^|]|%d|%d|%f %n",
                        &productID, name, &stock, &threshold, &price, &consumed);
        if (fields != 5 || line[consumed] != '\0' || productID <= 0 ||
            stock < 0 || threshold < 0 || !isfinite(price) || price < 0.0f ||
            !valid_product_name(name) || find_product(productID) != NULL) {
            fprintf(stderr, "Skipping invalid or duplicate record on line %d.\n",
                    lineNumber);
            continue;
        }

        product = (Product *)malloc(sizeof(*product));
        if (product == NULL) {
            perror("Could not allocate memory while loading inventory");
            fclose(file);
            return 0;
        }
        product->productID = productID;
        strcpy(product->productName, name);
        product->currentStock = stock;
        product->minThreshold = threshold;
        product->unitPrice = price;
        product->next = NULL;
        append_product(product);
    }

    if (ferror(file)) {
        perror("Could not read inventory.dat");
        fclose(file);
        return 0;
    }
    if (fclose(file) != 0) {
        perror("Could not close inventory.dat");
        return 0;
    }
    return 1;
}

static void add_product(void)
{
    Product *product;
    char name[INPUT_LENGTH];

    product = (Product *)malloc(sizeof(*product));
    if (product == NULL) {
        perror("Could not allocate memory for a new product");
        return;
    }

    if (!read_integer("Product ID: ", 1, INT_MAX, &product->productID)) {
        free(product);
        return;
    }
    if (find_product(product->productID) != NULL) {
        printf("Product ID %d already exists. No item was added.\n",
               product->productID);
        free(product);
        return;
    }

    for (;;) {
        if (!read_line("Product name: ", name, sizeof(name))) {
            free(product);
            return;
        }
        if (!valid_product_name(name) || strlen(name) >= PRODUCT_NAME_LENGTH) {
            puts("Name must contain 1-49 characters and cannot contain '|'.");
            continue;
        }
        strcpy(product->productName, name);
        break;
    }
    if (!read_integer("Current stock: ", 0, INT_MAX, &product->currentStock) ||
        !read_integer("Minimum threshold: ", 0, INT_MAX, &product->minThreshold) ||
        !read_price("Unit price: ", &product->unitPrice)) {
        free(product);
        return;
    }

    product->next = NULL;
    if (!append_product(product)) {
        puts("That product ID already exists. No item was added.");
        free(product);
        return;
    }

    puts("Product added successfully.");
    print_stock_status(product);
    if (save_inventory()) {
        puts("Inventory saved to inventory.dat.");
    }
}

static void update_stock(void)
{
    int productID;
    int choice;
    int quantity;
    Product *product;

    if (!read_integer("Product ID to update: ", 1, INT_MAX, &productID)) {
        return;
    }
    product = find_product(productID);
    if (product == NULL) {
        puts("Product not found.");
        return;
    }

    printf("%s - current stock: %d\n", product->productName, product->currentStock);
    puts("1. Add incoming stock");
    puts("2. Deduct sold/used stock");
    if (!read_integer("Choose an action: ", 1, 2, &choice) ||
        !read_integer("Quantity: ", 1, INT_MAX, &quantity)) {
        return;
    }

    if (choice == 1) {
        if (quantity > INT_MAX - product->currentStock) {
            puts("That quantity would exceed the maximum supported stock.");
            return;
        }
        product->currentStock += quantity;
        printf("Restocked successfully. New stock: %d\n", product->currentStock);
    } else {
        if (quantity > product->currentStock) {
            puts("Insufficient stock. The quantity was not changed.");
            return;
        }
        product->currentStock -= quantity;
        printf("Stock deducted successfully. New stock: %d\n", product->currentStock);
    }

    print_stock_status(product);
    if (save_inventory()) {
        puts("Inventory saved to inventory.dat.");
    }
}

static void print_table_header(void)
{
    printf("%-8s %-30s %12s %12s %12s %-10s\n",
           "ID", "Name", "Stock", "Minimum", "Price", "Status");
    puts("-----------------------------------------------------------------------------------------------");
}

static void print_product_row(const Product *product)
{
    printf("%-8d %-30.30s %12d %12d %12.2f %-10s\n",
           product->productID, product->productName, product->currentStock,
           product->minThreshold, product->unitPrice,
           product->currentStock <= product->minThreshold ? "LOW" : "OK");
}

static void view_inventory(void)
{
    const Product *current = inventoryHead;

    if (current == NULL) {
        puts("Inventory is empty.");
        return;
    }

    print_table_header();
    while (current != NULL) {
        print_product_row(current);
        current = current->next;
    }
}

static void show_low_stock(void)
{
    const Product *current = inventoryHead;
    int found = 0;

    while (current != NULL) {
        if (current->currentStock <= current->minThreshold) {
            if (!found) {
                print_table_header();
                found = 1;
            }
            print_product_row(current);
            print_stock_status(current);
        }
        current = current->next;
    }

    if (!found) {
        puts("No low-stock items. All products are above their minimum thresholds.");
    }
}

static void search_product(void)
{
    int productID;
    Product *product;

    if (!read_integer("Product ID to search: ", 1, INT_MAX, &productID)) {
        return;
    }
    product = find_product(productID);
    if (product == NULL) {
        puts("Product not found.");
        return;
    }

    print_table_header();
    print_product_row(product);
    print_stock_status(product);
}

static void delete_product(void)
{
    int productID;
    Product **link = &inventoryHead;
    Product *removed;

    if (!read_integer("Product ID to delete: ", 1, INT_MAX, &productID)) {
        return;
    }

    /*
     * Keep a pointer to the link that owns the current node. Updating it
     * handles deletion at the head and in the middle of the list uniformly.
     */
    while (*link != NULL && (*link)->productID != productID) {
        link = &(*link)->next;
    }
    if (*link == NULL) {
        puts("Product not found.");
        return;
    }

    removed = *link;
    *link = removed->next;
    printf("Deleted product: %s (ID %d).\n", removed->productName, removed->productID);
    free(removed);
    if (save_inventory()) {
        puts("Inventory saved to inventory.dat.");
    }
}

static void free_inventory(void)
{
    Product *current = inventoryHead;

    while (current != NULL) {
        Product *next = current->next;
        free(current);
        current = next;
    }
    inventoryHead = NULL;
}

static void display_menu(void)
{
    puts("\n========== STOCK INVENTORY MANAGEMENT ==========");
    puts("1. Add new stock item");
    puts("2. Update stock levels");
    puts("3. View low-stock alerts");
    puts("4. View inventory records");
    puts("5. Search for a product");
    puts("6. Delete a product");
    puts("0. Save and exit");
}

int main(void)
{
    int choice;

    if (!load_inventory()) {
        free_inventory();
        return EXIT_FAILURE;
    }

    printf("Inventory loaded. ");
    if (inventoryHead == NULL) {
        puts("There are currently no products.");
    } else {
        const Product *current = inventoryHead;
        int count = 0;
        while (current != NULL) {
            ++count;
            current = current->next;
        }
        printf("%d product(s) ready.\n", count);
    }

    for (;;) {
        display_menu();
        if (!read_integer("Select an option: ", 0, 6, &choice)) {
            puts("\nInput closed. Saving before exit.");
            break;
        }

        switch (choice) {
        case 1:
            add_product();
            break;
        case 2:
            update_stock();
            break;
        case 3:
            show_low_stock();
            break;
        case 4:
            view_inventory();
            break;
        case 5:
            search_product();
            break;
        case 6:
            delete_product();
            break;
        case 0:
            goto exit_program;
        }
    }

exit_program:
    if (save_inventory()) {
        printf("Inventory saved to %s.\n", DATA_FILE);
    }
    free_inventory();
    puts("All allocated memory released. Goodbye.");
    return EXIT_SUCCESS;
}
